/**
 * Oliver Lu, 101155667
 * Harishan Amutheesan, 101154757
 */
package mystore.exception;

public class ProductNotFoundException extends Exception{
    public ProductNotFoundException(String s){
        super(s);
    }
}
